const cluster 	 	= require('cluster'),
	  express 	 	= require('express'),
	  bodyParser 	= require('body-parser'),
	  port		 	= 8000;
var	  app		 	= express(),
	  bot_count		= 0;
	  workerObjects = [],
	  util		 	= require('util');



/*
if (cluster.isWorker) {

  console.log('Worker ' + cluster.worker.id + ' has started.');

  process.send({response: 'OK',
				processId : `${cluster.worker.id}`,
				cmd		: 'test'});

  // Receive messages from the master process.
  process.on('message', function(msg) {
    console.log('Worker ' + cluster.worker.id + ' received message from master.', msg);
  });

}
*/

if (cluster.isMaster) {
  /*App use*/
  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(bodyParser.json());
  /* Server logic */
  app.listen(port, () => {
  util.log('Server succes starts on  ' + port);
  });
  
  /* Create bots*/
  for (var i = 0; i < 0; i++) {
  	cluster.setupMaster({
  		exec: 'bot1.js',
  		args: [`${i}`, 'nT3J2aT3']
	});
    workerObjects[i] = cluster.fork();
    
  }
  /*API LOGIC*/
  app.post('/start', (req, res) => {
  	var bots = [req.body.count];
  	util.log(bot_count + " " + req.body.count);
  	if (bot_count < req.body.count){
  		for (var i = 1; i <= req.body.count; i++) {
	  		if (i < 15) {password = 'nT3J2aT3';}
	  		if (i == 8) {password = '1nT3J2aT3';}
	  		if (i > 14) {password = 'nT3J2aT2';}
	  		if (i > 19) {password = 'nT3J2aT1';}
	  		if (i > 24) {password = 'nT3J2aT0';}
	  		if (i > 29) {password = 'nT3J2aT9';}
	  		if (i > 34) {password = 'nT3J2aT8';}
	  		if (i > 39) {password = 'nT3J2aT7';}
	  		if (i > 44) {password = 'nT3J2aT6';}
	  		if (i > 49) {password = 'nT3J2aT5';}
	  		if (i > 54) {password = 'nT3J2aT4';}
	  		if (i > 59) {password = 'nT3J2aY9';}
	  		if (i > 61) {password = 'nT3J2aT300';}
	  		cluster.setupMaster({
	  			exec : 'bot1.js',
	  			args : [`${i}`, `${password}`]
	  		});
	  		workerObjects[i] = cluster.fork();
	  		workerObjects[i].send({data : {
	  			cmd : "start"
	  		}})
	  		bots[i] = workerObjects[i].isConnected();
	  		bot_count++;
	  		}
  		if(bots[req.body.count]){res.json(JSON.stringify(bots))};
  		bots = null;
    }
  	else {
  		res.send("Too many bots");
  	}
	});
  app.post('/createLobby', (req, res) => {
  	if(req.body.count == bot_count){
  		res.send('succes');
  		for (var i = 0; i < bot_count; i++) {
  			workerObjects[i+1].send({
  				data : {
  					cmd : "createLobby",
  					lobby : {
  						team1 : {  
  							name : `${req.body.lobby[i].team[0].name}`,
  							members : `${req.body.lobby[i].team[0].members}`
  						},
  						team2 : {
  							name : `${req.body.lobby[i].team[1].name}`,
  							members : `${req.body.lobby[i].team[1].members}`
  						}, 
  					}
  				}
  			});
  		}
  	}
  	if(req.body.count > bot_count){
  		res.send('Too many lobby config for current bots');
  	}
  	if(req.body.count < bot_count){
  		res.send('Not enough lobby config for current bots');
  	}
  });

  //console.log(workerObjects[1].isConnected());
  // Be notified when worker processes die.
  //workerObjects[1].send({test : "test"});
  cluster.on('death', function(worker) {
    console.log('Worker ' + worker.pid + ' died.');
  });
  cluster.on('message', function(worker, msg, handle) {
  	  switch(msg.data){

  	  }
      //console.log('Master ' + process.pid + ' received message from worker ' + worker.id + '.', msg);
    });

}