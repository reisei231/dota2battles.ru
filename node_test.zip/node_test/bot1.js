var cluster = require('cluster');
var steam = require("steam"),
    util = require("util"),
    fs = require("fs"),
    crypto = require("crypto"),
    dota2 = require("./index.js"),
    steamClient = new steam.SteamClient(),
    steamUser = new steam.SteamUser(steamClient),
    steamFriends = new steam.SteamFriends(steamClient),
    Dota2 = new dota2.Dota2Client(steamClient, true),
    stageBot = "wait";
// Load config
var id = process.argv[2];
    var logOnDetails = {
        "account_name": 'd2battles' + id,
        "password": process.argv[3],
    };
    if(id == 64){
        var logOnDetails = {
        "account_name": 'd2battles' + 65,
        "password": process.argv[3],
    };
    }
    /* Process logic */
    


/*
process.send({
    data : {
        status : 'ok'
    }
})
process.on('message', (msg) =>{

    util.log('New message ' + msg.data)
});
*/
    /* Steam logic */
    var onSteamLogOn = function onSteamLogOn(logonResp) {
        if (logonResp.eresult == 1){
            util.log(`BOT #${id} steam success`);
            process.send({
                id : `${id}`,
                reposnse : 'connect'
            })
        };
        if (logonResp.eresult != 1){util.log(`BOT #${id} error: ${logonResp.eresult} :  ${process.argv[3]} : ${id}`);}
        cluster.worker.on('message', (msg) => {
            switch(msg.data.cmd){
                case 'createLobby':
                    Dota2.launch();
                    Dota2.on("ready", () =>{
                        util.log(`[${id}] Dota 2 is ready`);
                        Dota2.destroyLobby();// Удаляем лобби, если какое-либо лобби существует
                        var lobbyConfig = { // Cоздаем конфиг лобби
                            "game_name": `${msg.data.lobby.team1.name} vs ${msg.data.lobby.team2.name}`, // 
                            "server_region": dota2.ServerRegion.EUROPE,
                            "game_mode": dota2.schema.lookupEnum('DOTA_GameMode').values.DOTA_GAMEMODE_AP,
                            // На вермя дебага режим изменен на All Pick
                            "game_version": 1,
                            "allow_cheats": true, // На время дебага включены читы 
                            "fill_with_bots": true, // На время дебага включены боты
                            "allow_spectating": true,
                            "pass_key": "",
                            "radiant_series_wins": 0,
                            "dire_series_wins": 0,
                            "allchat": true
                        }
                        /* Создаем лобби по конфигу */
                        Dota2.createPracticeLobby(lobbyConfig, function(err, data){
                            if (err) {
                                /*toDo кидаем на сервер d2battles о том, что лобби создалось*/
                                util.log(err + ' - ' + JSON.stringify(data));
                            }
                            team1 = msg.data.lobby.team1.members.split(',');
                            team2 = msg.data.lobby.team2.members.split(',');
                            for (var i = 0; i < team1.length; i++) {
                                Dota2.inviteToLobby(team1[i]);
                            }
                            for (var i = 0; i < team2.length; i++) {
                                Dota2.inviteToLobby(team2[i]);
                            }
                            //util.log(team1);
                            Dota2.practiceLobbyKickFromTeam(Dota2.AccountID);
                        });

                        /* Слуашем события лобби 
                        if ((msg.data.lobby.team1.members.indexOf(parseInt(lobby.members[0].id)) == -1) && (lobby.members[0].id == "76561198807432163")) {
                                util.log(lobby.members[0].id + " is WRONG USER");
                            }
                        */
                        Dota2.on("practiceLobbyUpdate", function(lobby) {
                            // Заходим в чат лобби
                            lobbyChannel = "Lobby_"+lobby.lobby_id;
                            Dota2.joinChat(lobbyChannel, dota2.schema.lookupEnum('DOTAChatChannelType_t').values.DOTAChannelType_Lobby);                            /* Система исключения ненужных игроков из лобби */
                            switch(lobby.members.length){
                                case 1:
                                    //util.log("В лобби 1 человек");
                                    break;
                                case 2:
                                    //util.log("В лобби 2 человека");
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id) == -1)) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    break;
                                case 3:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    break;
                                case 4:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    break;
                                case 5:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    break;
                                case 6:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    break;
                                case 7:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[6].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[6].id));
                                    }
                                    break;
                                case 8:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[6].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[6].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[7].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[7].id));
                                    }
                                    break;
                                case 9:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[6].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[6].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[7].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[7].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[8].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[8].id));
                                    }
                                    break;
                                case 10:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[6].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[6].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[7].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[7].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[8].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[8].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[9].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[9].id));
                                    }
                                    break;
                                case 11:
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[1].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[1].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[1].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[2].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[2].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[3].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[3].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[4].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[4].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[5].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[5].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[6].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[6].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[7].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[7].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[8].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[8].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[9].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[9].id));
                                    }
                                    if ((msg.data.lobby.team1.members.indexOf(lobby.members[10].id) == -1) && (msg.data.lobby.team2.members.indexOf(lobby.members[2].id))) {
                                        
                                        Dota2.practiceLobbyKick(Dota2.ToAccountID(lobby.members[10].id));
                                    }
                                    break;
                            }

                        });

                        
                    })
            }
            //util.log(`Get new message ` + msg.data.cmd + "\n" + msg.data.lobby.team1.name);
        });
    }
    onSteamServers = function onSteamServers(servers) {
        fs.writeFile('servers', JSON.stringify(servers), (err) => {
            if (err) { if (this.debug) util.log("Error writing "); }
            else { if (this.debug) util.log(""); }
        });
    },
    onSteamLogOff = function onSteamLogOff(eresult) {
        util.log("Logged off from Steam.");
    },
    onSteamError = function onSteamError(error) {
        //util.log("Connection closed by server: " + error);
    };

    steamUser.on('updateMachineAuth', function (sentry, callback) {
        var hashedSentry = crypto.createHash('sha1').update(sentry.bytes).digest();
        fs.writeFileSync('sentry', hashedSentry)
        util.log("sentryfile saved");
        callback({
            sha_file: hashedSentry
        });
    });


    // Login, only passing authCode if it exists
    
    try {
        var sentry = fs.readFileSync('sentry');
        if (sentry.length) logOnDetails.sha_sentryfile = sentry;
    } catch (beef) {
        //util.log("Cannae load the sentry. " + beef);
    }
    process.on('message', (msg) =>{
    if(msg.data.cmd == 'start'){
        steamClient.connect();
        steamClient.on('connected', function () {
            steamUser.logOn(logOnDetails);
        });
        steamClient.on('logOnResponse', onSteamLogOn);
        steamClient.on('loggedOff', onSteamLogOff);
        steamClient.on('error', onSteamError);
        steamClient.on('servers', onSteamServers);
    } 
    });
    