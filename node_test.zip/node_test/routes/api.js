// routes/note_routes.js
module.exports = function(app, db) {
};