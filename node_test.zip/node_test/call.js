var pm2 = require('pm2');

pm2.connect(function(err) {
  if(err) {
    console.log(err);
    process.exit(2);
  }

  pm2.start({
    script: 'app.js'
  }, function(err, apps) {
    if (err)
      throw err;

    console.log('create process');

    pm2.sendDataToProcessId(apps[0].pm2_env.pm_id, {
      type: 'process:msg',
      data: {
        some: 'data',
        hello: true
      },
      topic: 'my topic'
    }, function(err, res) {
      if (err)
        throw err;

      console.log('res is ', res);
    });
  });
});

pm2.launchBus(function(err, bus) {
  bus.on('process:msg', function(packet) {
    console.log(packet);
  });
});