var start = Date.now();

if (process['send']) {
  console.log('have');
}

process.on('message', function(packet) {
  console.log('GET MESSAGE: ', packet);

  process.send({
    type: 'process:msg',
    data: {
      success: true
    },
    topic: 'abc'
  });
});
